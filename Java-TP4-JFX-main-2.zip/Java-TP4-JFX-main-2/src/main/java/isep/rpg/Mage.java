package isep.rpg;

public class Mage extends SpellCaster {
    public Mage() {this.setLifePoints(5);}
    @Override
    public boolean attack(Fighter enemy) {
        return enemy.receiveAttack(5);
    }
}

