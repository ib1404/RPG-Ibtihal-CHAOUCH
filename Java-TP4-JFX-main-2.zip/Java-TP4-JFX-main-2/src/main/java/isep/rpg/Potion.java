package isep.rpg;

public class Potion implements Consumable {
}
