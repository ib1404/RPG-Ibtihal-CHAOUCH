package isep.rpg;

public interface Consumable {
}
