package isep.rpg;

public class Boss extends Enemy {}
