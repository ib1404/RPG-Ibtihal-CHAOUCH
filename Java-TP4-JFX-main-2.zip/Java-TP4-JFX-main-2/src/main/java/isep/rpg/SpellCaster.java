package isep.rpg;

public abstract class SpellCaster extends Hero {

    private int manaPoints;

}
