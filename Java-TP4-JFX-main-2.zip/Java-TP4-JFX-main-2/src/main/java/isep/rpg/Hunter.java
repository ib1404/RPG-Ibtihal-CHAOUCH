package isep.rpg;

public class Hunter extends Hero {

    private int arrows;

    public Hunter() {this.setLifePoints(5);}
    @Override
    public boolean attack(Fighter enemy) {
        return enemy.receiveAttack(5);
    }

}
